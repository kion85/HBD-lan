#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <cstdint>
#include <algorithm>
#include <iomanip>

class HybridAsmInterpreter {
private:
    // Регистры и память
    uint8_t registers[8] = {0}; // R0-R7
    uint8_t memory[65536] = {0}; // 64KB памяти
    uint16_t sp = 0xFFFF; // Указатель стека (растет вниз)
    uint16_t pc = 0; // Счетчик команд
    
    // Флаги
    bool flagZ = false; // Zero
    bool flagC = false; // Carry
    bool flagS = false; // Sign
    
    // Таблица меток
    std::map<std::string, uint16_t> labels;
    
    // Текущая программа
    std::vector<std::string> program;
    
    // Преобразование строки в число
    uint8_t parseNumber(const std::string& str) {
        if (str.find("0x") == 0) {
            return std::stoul(str.substr(2), nullptr, 16);
        }
        return std::stoul(str);
    }
    
    // Получение номера регистра из строки
    int getRegisterIndex(const std::string& reg) {
        if (reg.size() == 2 && reg[0] == 'R') {
            return reg[1] - '0';
        }
        return -1;
    }
    
    // Обновление флагов после операции
    void updateFlags(uint8_t result) {
        flagZ = (result == 0);
        flagS = (result & 0x80) != 0;
    }
    
    // Обработка операнда (регистр или число)
    uint8_t getOperandValue(const std::string& op) {
        if (op[0] == 'R') {
            int regIndex = getRegisterIndex(op);
            if (regIndex != -1) {
                return registers[regIndex];
            }
        }
        return parseNumber(op);
    }
    
    // Выполнение инструкции
    bool executeInstruction(const std::string& line) {
        std::istringstream iss(line);
        std::string instruction;
        iss >> instruction;
        
        // Пропускаем метки
        if (instruction.back() == ':') {
            return true;
        }
        
        // Преобразование hex-кодов в мнемоники
        if (instruction == "0x93") instruction = "ADD";
        else if (instruction == "0x82") instruction = "SUB";
        else if (instruction == "0xA1") instruction = "MUL";
        else if (instruction == "0xB2") instruction = "DIV";
        else if (instruction == "0x4A") instruction = "INC";
        else if (instruction == "0x5B") instruction = "DEC";
        else if (instruction == "0xC3") instruction = "AND";
        else if (instruction == "0xD4") instruction = "OR";
        else if (instruction == "0xE5") instruction = "XOR";
        else if (instruction == "0xF6") instruction = "NOT";
        else if (instruction == "0x17") instruction = "SHL";
        else if (instruction == "0x28") instruction = "SHR";
        else if (instruction == "0x39") instruction = "ROTATE";
        else if (instruction == "0x73") instruction = "JG";
        else if (instruction == "0xA0") instruction = "JZ";
        else if (instruction == "0xB1") instruction = "JNZ";
        else if (instruction == "0xC2") instruction = "JL";
        else if (instruction == "0xD3") instruction = "JGE";
        else if (instruction == "0xE4") instruction = "JLE";
        else if (instruction == "0x7D") instruction = "JE";
        else if (instruction == "0x8E") instruction = "JNE";
        else if (instruction == "0x9F") instruction = "JMP";
        else if (instruction == "0x6C") instruction = "PUSH";
        else if (instruction == "0x7D") instruction = "POP";
        else if (instruction == "0x8E") instruction = "CALL";
        else if (instruction == "0xD1") instruction = "RET";
        else if (instruction == "0x06") instruction = "LOAD";
        else if (instruction == "0x17") instruction = "STORE";
        else if (instruction == "0x28") instruction = "IN";
        else if (instruction == "0x39") instruction = "OUT";
        else if (instruction == "0x4A") instruction = "NOP";
        else if (instruction == "0xF5") instruction = "HALT";
        else if (instruction == "0x5B") instruction = "MOV";
        else if (instruction == "0x6C") instruction = "CMP";
        else if (instruction == "0x9F") instruction = "TEST";
        
        std::string op1, op2;
        iss >> op1;
        if (!iss.eof()) {
            iss >> op2;
            // Удаляем запятые
            op1.erase(std::remove(op1.begin(), op1.end(), ','), op1.end());
            op2.erase(std::remove(op2.begin(), op2.end(), ','), op2.end());
        }
        
        if (instruction == "MOV") {
            int regIndex = getRegisterIndex(op1);
            if (regIndex != -1) {
                registers[regIndex] = getOperandValue(op2);
            }
        }
        else if (instruction == "ADD") {
            int regIndex = getRegisterIndex(op1);
            if (regIndex != -1) {
                uint16_t result = registers[regIndex] + getOperandValue(op2);
                registers[regIndex] = result & 0xFF;
                flagC = (result > 0xFF);
                updateFlags(registers[regIndex]);
            }
        }
        else if (instruction == "SUB") {
            int regIndex = getRegisterIndex(op1);
            if (regIndex != -1) {
                uint8_t oldValue = registers[regIndex];
                registers[regIndex] -= getOperandValue(op2);
                flagC = (getOperandValue(op2) > oldValue);
                updateFlags(registers[regIndex]);
            }
        }
        else if (instruction == "MUL") {
            int regIndex = getRegisterIndex(op1);
            if (regIndex != -1) {
                uint16_t result = registers[regIndex] * getOperandValue(op2);
                registers[regIndex] = result & 0xFF;
                flagC = (result > 0xFF);
                updateFlags(registers[regIndex]);
            }
        }
        else if (instruction == "DIV") {
            int regIndex = getRegisterIndex(op1);
            if (regIndex != -1) {
                uint8_t divisor = getOperandValue(op2);
                if (divisor != 0) {
                    registers[regIndex] /= divisor;
                    updateFlags(registers[regIndex]);
                }
            }
        }
        else if (instruction == "INC") {
            int regIndex = getRegisterIndex(op1);
            if (regIndex != -1) {
                registers[regIndex]++;
                updateFlags(registers[regIndex]);
            }
        }
        else if (instruction == "DEC") {
            int regIndex = getRegisterIndex(op1);
            if (regIndex != -1) {
                registers[regIndex]--;
                updateFlags(registers[regIndex]);
            }
        }
        else if (instruction == "AND") {
            int regIndex = getRegisterIndex(op1);
            if (regIndex != -1) {
                registers[regIndex] &= getOperandValue(op2);
                updateFlags(registers[regIndex]);
            }
        }
        else if (instruction == "OR") {
            int regIndex = getRegisterIndex(op1);
            if (regIndex != -1) {
                registers[regIndex] |= getOperandValue(op2);
                updateFlags(registers[regIndex]);
            }
        }
        else if (instruction == "XOR") {
            int regIndex = getRegisterIndex(op1);
            if (regIndex != -1) {
                registers[regIndex] ^= getOperandValue(op2);
                updateFlags(registers[regIndex]);
            }
        }
        else if (instruction == "NOT") {
            int regIndex = getRegisterIndex(op1);
            if (regIndex != -1) {
                registers[regIndex] = ~registers[regIndex];
                updateFlags(registers[regIndex]);
            }
        }
        else if (instruction == "SHL") {
            int regIndex = getRegisterIndex(op1);
            if (regIndex != -1) {
                uint8_t shift = getOperandValue(op2);
                flagC = (registers[regIndex] & 0x80) != 0;
                registers[regIndex] <<= shift;
                updateFlags(registers[regIndex]);
            }
        }
        else if (instruction == "SHR") {
            int regIndex = getRegisterIndex(op1);
            if (regIndex != -1) {
                uint8_t shift = getOperandValue(op2);
                flagC = (registers[regIndex] & 0x01) != 0;
                registers[regIndex] >>= shift;
                updateFlags(registers[regIndex]);
            }
        }
        else if (instruction == "CMP") {
            uint8_t val1 = getOperandValue(op1);
            uint8_t val2 = getOperandValue(op2);
            flagZ = (val1 == val2);
            flagS = (val1 < val2);
        }
        else if (instruction == "TEST") {
            uint8_t val1 = getOperandValue(op1);
            uint8_t val2 = getOperandValue(op2);
            uint8_t result = val1 & val2;
            flagZ = (result == 0);
            flagS = (result & 0x80) != 0;
        }
        else if (instruction == "JE" || instruction == "JZ") {
            if (flagZ) {
                pc = labels[op1];
                return true;
            }
        }
        else if (instruction == "JNE" || instruction == "JNZ") {
            if (!flagZ) {
                pc = labels[op1];
                return true;
            }
        }
        else if (instruction == "JG") {
            if (!flagZ && !flagS) {
                pc = labels[op1];
                return true;
            }
        }
        else if (instruction == "JL") {
            if (flagS) {
                pc = labels[op1];
                return true;
            }
        }
        else if (instruction == "JGE") {
            if (!flagS) {
                pc = labels[op1];
                return true;
            }
        }
        else if (instruction == "JLE") {
            if (flagZ || flagS) {
                pc = labels[op1];
                return true;
            }
        }
        else if (instruction == "JMP") {
            pc = labels[op1];
            return true;
        }
        else if (instruction == "PUSH") {
            int regIndex = getRegisterIndex(op1);
            if (regIndex != -1) {
                memory[sp] = registers[regIndex];
                sp--;
            }
        }
        else if (instruction == "POP") {
            int regIndex = getRegisterIndex(op1);
            if (regIndex != -1) {
                sp++;
                registers[regIndex] = memory[sp];
            }
        }
        else if (instruction == "CALL") {
            // Сохраняем адрес возврата
            memory[sp] = pc & 0xFF;
            sp--;
            memory[sp] = (pc >> 8) & 0xFF;
            sp--;
            // Переход к подпрограмме
            pc = labels[op1];
            return true;
        }
        else if (instruction == "RET") {
            // Восстанавливаем адрес возврата
            sp++;
            uint8_t high = memory[sp];
            sp++;
            uint8_t low = memory[sp];
            pc = (high << 8) | low;
            return true;
        }
        else if (instruction == "LOAD") {
            int regIndex = getRegisterIndex(op1);
            if (regIndex != -1 && op2[0] == '[' && op2[op2.size()-1] == ']') {
                std::string addrStr = op2.substr(1, op2.size()-2);
                uint16_t addr = parseNumber(addrStr);
                registers[regIndex] = memory[addr];
            }
        }
        else if (instruction == "STORE") {
            if (op1[0] == '[' && op1[op1.size()-1] == ']') {
                std::string addrStr = op1.substr(1, op1.size()-2);
                uint16_t addr = parseNumber(addrStr);
                int regIndex = getRegisterIndex(op2);
                if (regIndex != -1) {
                    memory[addr] = registers[regIndex];
                }
            }
        }
        else if (instruction == "IN") {
            int regIndex = getRegisterIndex(op1);
            if (regIndex != -1) {
                // Эмуляция ввода - всегда возвращает 0
                registers[regIndex] = 0;
            }
        }
        else if (instruction == "OUT") {
            uint8_t port = parseNumber(op1);
            int regIndex = getRegisterIndex(op2);
            if (regIndex != -1) {
                std::cout << "PORT " << (int)port << ": " << (int)registers[regIndex] << std::endl;
            }
        }
        else if (instruction == "HALT") {
            return false;
        }
        else if (instruction == "NOP") {
            // Ничего не делаем
        }
        
        return true;
    }
    
    // Первый проход: сбор меток
    void collectLabels() {
        for (uint16_t i = 0; i < program.size(); i++) {
            std::string line = program[i];
            size_t colonPos = line.find(':');
            if (colonPos != std::string::npos) {
                std::string label = line.substr(0, colonPos);
                labels[label] = i;
            }
        }
    }

public:
    HybridAsmInterpreter() {}
    
    // Загрузка программы из файла
    bool loadProgram(const std::string& filename) {
        std::ifstream file(filename);
        if (!file.is_open()) {
            std::cerr << "Error: Cannot open file " << filename << std::endl;
            return false;
        }
        
        program.clear();
        std::string line;
        while (std::getline(file, line)) {
            // Удаляем комментарии
            size_t commentPos = line.find(';');
            if (commentPos != std::string::npos) {
                line = line.substr(0, commentPos);
            }
            // Удаляем начальные и конечные пробелы
            line.erase(0, line.find_first_not_of(" \t"));
            line.erase(line.find_last_not_of(" \t") + 1);
            
            if (!line.empty()) {
                program.push_back(line);
            }
        }
        
        file.close();
        collectLabels();
        return true;
    }
    
    // Выполнение программы
    void run() {
        pc = 0;
        while (pc < program.size()) {
            std::string line = program[pc];
            pc++;
            
            if (!executeInstruction(line)) {
                break; // HALT
            }
        }
    }
    
    // Вывод состояния процессора
    void dumpState() {
        std::cout << "=== PROCESSOR STATE ===" << std::endl;
        for (int i = 0; i < 8; i++) {
            std::cout << "R" << i << " = 0x" << std::hex << std::setw(2) << std::setfill('0') 
                      << (int)registers[i] << std::dec << " (" << (int)registers[i] << ")" << std::endl;
        }
        std::cout << "SP = 0x" << std::hex << sp << std::dec << std::endl;
        std::cout << "Flags: Z=" << flagZ << " C=" << flagC << " S=" << flagS << std::endl;
    }
};

int main(int argc, char* argv[]) {
    if (argc != 2) {
        std::cout << "Usage: " << argv[0] << " <program.mah>" << std::endl;
        return 1;
    }
    
    HybridAsmInterpreter interpreter;
    if (interpreter.loadProgram(argv[1])) {
        interpreter.run();
        interpreter.dumpState();
    }
    
    return 0;
}
