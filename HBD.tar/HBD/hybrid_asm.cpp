#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <map>
#include <cstdint>
#include <algorithm>
#include <functional>
#include <iomanip>

class HybridAsmInterpreter {
private:
    // Регистры и память
    uint8_t registers[8] = {0}; // R0-R7
    uint8_t memory[65536] = {0};
    uint16_t pc = 0; // program counter
    uint16_t sp = 0xFF00; // stack pointer
    bool flags[3] = {false}; // Z (zero), C (carry), S (sign)
    
    // Таблицы
    std::map<std::string, uint16_t> labels;
    std::vector<std::string> program;
    bool running = true;
    
    // Коды операций
    enum OpCode {
        MOV, ADD, SUB, MUL, DIV, CMP, JE, JNE, JMP, NOP,
        PUSH, POP, CALL, RET, LOAD, STORE, AND, OR, XOR,
        NOT, SHL, SHR, ROTATE, IN, OUT, HALT, INC, DEC, TEST, JZ,
        JG, JGE, JL, JLE, JNZ
    };
    
    // Таблица мнемоник
    std::map<std::string, OpCode> opcodeMap = {
        {"MOV", MOV}, {"ADD", ADD}, {"SUB", SUB}, {"MUL", MUL},
        {"DIV", DIV}, {"CMP", CMP}, {"JE", JE}, {"JNE", JNE},
        {"JMP", JMP}, {"NOP", NOP}, {"PUSH", PUSH}, {"POP", POP},
        {"CALL", CALL}, {"RET", RET}, {"LOAD", LOAD}, {"STORE", STORE},
        {"AND", AND}, {"OR", OR}, {"XOR", XOR}, {"NOT", NOT},
        {"SHL", SHL}, {"SHR", SHR}, {"ROTATE", ROTATE}, {"IN", IN},
        {"OUT", OUT}, {"HALT", HALT}, {"INC", INC}, {"DEC", DEC},
        {"TEST", TEST}, {"JZ", JZ}, {"JG", JG}, {"JGE", JGE},
        {"JL", JL}, {"JLE", JLE}, {"JNZ", JNZ}
    };
    
    // Таблица машинных кодов
    std::map<uint8_t, OpCode> machineCodeMap = {
        {0x93, ADD}, {0x82, SUB}, {0x73, JG}, {0xD1, RET},
        {0xA1, MUL}, {0xB2, DIV}, {0xC3, AND}, {0xD4, OR},
        {0xE5, XOR}, {0xF6, NOT}, {0x17, SHL}, {0x28, SHR},
        {0x39, ROTATE}, {0x4A, INC}, {0x5B, DEC}, {0x6C, PUSH},
        {0x7D, POP}, {0x8E, CALL}, {0x9F, TEST}, {0xA0, JZ},
        {0xB1, JNZ}, {0xC2, JL}, {0xD3, JGE}, {0xE4, JLE},
        {0xF5, HALT}, {0x06, LOAD}, {0x17, STORE}, {0x28, IN},
        {0x39, OUT}, {0x4A, NOP}, {0x5B, MOV}, {0x6C, CMP},
        {0x7D, JE}, {0x8E, JNE}, {0x9F, JMP}
    };

public:
    HybridAsmInterpreter(const std::vector<std::string>& code) : program(code) {
        parseLabels();
        sp = 0xFF00; // Инициализация стека
    }
    
    void parseLabels() {
        for (size_t i = 0; i < program.size(); i++) {
            std::string line = program[i];
            // Удаляем комментарии
            size_t commentPos = line.find(';');
            if (commentPos != std::string::npos) {
                line = line.substr(0, commentPos);
            }
            
            size_t colonPos = line.find(':');
            if (colonPos != std::string::npos) {
                std::string label = line.substr(0, colonPos);
                // Удаляем пробелы
                label.erase(std::remove_if(label.begin(), label.end(), ::isspace), label.end());
                if (!label.empty()) {
                    labels[label] = i;
                }
            }
        }
    }
    
    int getRegisterIndex(const std::string& reg) {
        if (reg.size() >= 2 && reg[0] == 'R') {
            char regChar = reg[1];
            if (regChar >= '0' && regChar <= '7') {
                return regChar - '0';
            }
        }
        return -1;
    }
    
    bool isRegister(const std::string& str) {
        return getRegisterIndex(str) != -1;
    }
    
    uint8_t parseValue(const std::string& str) {
        if (str.empty()) return 0;
        
        try {
            if (str.substr(0, 2) == "0x") {
                return static_cast<uint8_t>(std::stoul(str.substr(2), nullptr, 16));
            } else if (str[0] == '[') {
                // Обработка адреса памяти [0x1234]
                std::string addrStr = str.substr(1, str.size() - 2);
                if (addrStr.substr(0, 2) == "0x") {
                    uint16_t addr = static_cast<uint16_t>(std::stoul(addrStr.substr(2), nullptr, 16));
                    return memory[addr];
                }
            }
            return static_cast<uint8_t>(std::stoi(str));
        } catch (...) {
            return 0;
        }
    }
    
    uint16_t parseAddress(const std::string& str) {
        if (str.substr(0, 2) == "0x") {
            return static_cast<uint16_t>(std::stoul(str.substr(2), nullptr, 16));
        }
        return static_cast<uint16_t>(std::stoi(str));
    }
    
    void updateFlags(uint8_t value) {
        flags[0] = (value == 0); // Z flag
        flags[2] = (value & 0x80); // S flag (знаковый бит)
    }
    
    void pushStack(uint8_t value) {
        if (sp > 0) {
            memory[sp] = value;
            sp--;
        }
    }
    
    uint8_t popStack() {
        if (sp < 0xFF00) {
            sp++;
            return memory[sp];
        }
        return 0;
    }
    
    void execute() {
        while (running && pc < program.size()) {
            std::string line = program[pc];
            
            // Удаляем комментарии
            size_t commentPos = line.find(';');
            if (commentPos != std::string::npos) {
                line = line.substr(0, commentPos);
            }
            
            // Пропускаем пустые строки
            if (line.empty() || line.find_first_not_of(" \t") == std::string::npos) {
                pc++;
                continue;
            }
            
            std::istringstream iss(line);
            std::string token;
            
            // Пропускаем метки если есть
            size_t colonPos = line.find(':');
            if (colonPos != std::string::npos) {
                iss >> token; // пропускаем метку
            }
            
            if (!(iss >> token)) {
                pc++;
                continue;
            }
            
            if (token.empty() || token[0] == ';') {
                pc++;
                continue;
            }
            
            // Выполняем инструкцию
            if (token.substr(0, 2) == "0x") {
                uint8_t machineCode = parseValue(token);
                executeMachineCode(machineCode, iss);
            } else {
                executeMnemonic(token, iss);
            }
            
            if (running) {
                pc++;
            }
        }
    }
    
    void executeMnemonic(const std::string& op, std::istringstream& iss) {
        auto it = opcodeMap.find(op);
        if (it == opcodeMap.end()) {
            std::cout << "Unknown instruction: " << op << std::endl;
            return;
        }
        
        std::vector<std::string> operands;
        std::string operand;
        while (iss >> operand) {
            if (operand != ",") {
                operands.push_back(operand);
            }
        }
        
        switch (it->second) {
            case MOV: {
                if (operands.size() >= 2) {
                    int reg = getRegisterIndex(operands[0]);
                    if (reg != -1) {
                        registers[reg] = parseValue(operands[1]);
                    }
                }
                break;
            }
            case ADD: {
                if (operands.size() >= 2) {
                    int reg1 = getRegisterIndex(operands[0]);
                    int reg2 = getRegisterIndex(operands[1]);
                    if (reg1 != -1 && reg2 != -1) {
                        registers[reg1] += registers[reg2];
                        updateFlags(registers[reg1]);
                    }
                }
                break;
            }
            case SUB: {
                if (operands.size() >= 2) {
                    int reg1 = getRegisterIndex(operands[0]);
                    int reg2 = getRegisterIndex(operands[1]);
                    if (reg1 != -1 && reg2 != -1) {
                        registers[reg1] -= registers[reg2];
                        updateFlags(registers[reg1]);
                    }
                }
                break;
            }
            case MUL: {
                if (operands.size() >= 2) {
                    int reg1 = getRegisterIndex(operands[0]);
                    int reg2 = getRegisterIndex(operands[1]);
                    if (reg1 != -1 && reg2 != -1) {
                        registers[reg1] *= registers[reg2];
                        updateFlags(registers[reg1]);
                    }
                }
                break;
            }
            case DIV: {
                if (operands.size() >= 2) {
                    int reg1 = getRegisterIndex(operands[0]);
                    int reg2 = getRegisterIndex(operands[1]);
                    if (reg1 != -1 && reg2 != -1 && registers[reg2] != 0) {
                        registers[reg1] /= registers[reg2];
                        updateFlags(registers[reg1]);
                    }
                }
                break;
            }
            case CMP: {
                if (operands.size() >= 2) {
                    uint8_t val1 = isRegister(operands[0]) ? registers[getRegisterIndex(operands[0])] : parseValue(operands[0]);
                    uint8_t val2 = isRegister(operands[1]) ? registers[getRegisterIndex(operands[1])] : parseValue(operands[1]);
                    flags[0] = (val1 == val2);
                    flags[1] = (val1 < val2);
                    flags[2] = (val1 > val2);
                }
                break;
            }
            case JE: {
                if (operands.size() >= 1 && flags[0]) {
                    if (labels.find(operands[0]) != labels.end()) {
                        pc = labels[operands[0]] - 1;
                    }
                }
                break;
            }
            case JNE: {
                if (operands.size() >= 1 && !flags[0]) {
                    if (labels.find(operands[0]) != labels.end()) {
                        pc = labels[operands[0]] - 1;
                    }
                }
                break;
            }
            case JMP: {
                if (operands.size() >= 1) {
                    if (labels.find(operands[0]) != labels.end()) {
                        pc = labels[operands[0]] - 1;
                    }
                }
                break;
            }
            case NOP: break;
            
            case PUSH: {
                if (operands.size() >= 1) {
                    int reg = getRegisterIndex(operands[0]);
                    if (reg != -1) {
                        pushStack(registers[reg]);
                    } else {
                        pushStack(parseValue(operands[0]));
                    }
                }
                break;
            }
            case POP: {
                if (operands.size() >= 1) {
                    int reg = getRegisterIndex(operands[0]);
                    if (reg != -1) {
                        registers[reg] = popStack();
                    }
                }
                break;
            }
            case CALL: {
                if (operands.size() >= 1) {
                    if (labels.find(operands[0]) != labels.end()) {
                        pushStack(pc >> 8);
                        pushStack(pc & 0xFF);
                        pc = labels[operands[0]] - 1;
                    }
                }
                break;
            }
            case RET: {
                uint8_t low = popStack();
                uint8_t high = popStack();
                pc = ((high << 8) | low);
                break;
            }
            case LOAD: {
                if (operands.size() >= 2) {
                    int reg = getRegisterIndex(operands[0]);
                    if (reg != -1) {
                        uint16_t addr = parseAddress(operands[1].substr(1, operands[1].size() - 2));
                        registers[reg] = memory[addr];
                    }
                }
                break;
            }
            case STORE: {
                if (operands.size() >= 2) {
                    uint16_t addr = parseAddress(operands[0].substr(1, operands[0].size() - 2));
                    int reg = getRegisterIndex(operands[1]);
                    if (reg != -1) {
                        memory[addr] = registers[reg];
                    }
                }
                break;
            }
            case AND: {
                if (operands.size() >= 2) {
                    int reg1 = getRegisterIndex(operands[0]);
                    int reg2 = getRegisterIndex(operands[1]);
                    if (reg1 != -1 && reg2 != -1) {
                        registers[reg1] &= registers[reg2];
                        updateFlags(registers[reg1]);
                    }
                }
                break;
            }
            case OR: {
                if (operands.size() >= 2) {
                    int reg1 = getRegisterIndex(operands[0]);
                    int reg2 = getRegisterIndex(operands[1]);
                    if (reg1 != -1 && reg2 != -1) {
                        registers[reg1] |= registers[reg2];
                        updateFlags(registers[reg1]);
                    }
                }
                break;
            }
            case XOR: {
                if (operands.size() >= 2) {
                    int reg1 = getRegisterIndex(operands[0]);
                    int reg2 = getRegisterIndex(operands[1]);
                    if (reg1 != -1 && reg2 != -1) {
                        registers[reg1] ^= registers[reg2];
                        updateFlags(registers[reg1]);
                    }
                }
                break;
            }
            case NOT: {
                if (operands.size() >= 1) {
                    int reg = getRegisterIndex(operands[0]);
                    if (reg != -1) {
                        registers[reg] = ~registers[reg];
                        updateFlags(registers[reg]);
                    }
                }
                break;
            }
            case SHL: {
                if (operands.size() >= 2) {
                    int reg = getRegisterIndex(operands[0]);
                    uint8_t bits = parseValue(operands[1]);
                    if (reg != -1) {
                        registers[reg] <<= bits;
                        updateFlags(registers[reg]);
                    }
                }
                break;
            }
            case SHR: {
                if (operands.size() >= 2) {
                    int reg = getRegisterIndex(operands[0]);
                    uint8_t bits = parseValue(operands[1]);
                    if (reg != -1) {
                        registers[reg] >>= bits;
                        updateFlags(registers[reg]);
                    }
                }
                break;
            }
            case ROTATE: {
                if (operands.size() >= 2) {
                    int reg = getRegisterIndex(operands[0]);
                    uint8_t bits = parseValue(operands[1]);
                    if (reg != -1) {
                        registers[reg] = (registers[reg] << bits) | (registers[reg] >> (8 - bits));
                        updateFlags(registers[reg]);
                    }
                }
                break;
            }
            case IN: {
                if (operands.size() >= 2) {
                    int reg = getRegisterIndex(operands[0]);
                    uint8_t port = parseValue(operands[1]);
                    if (reg != -1) {
                        // Симуляция ввода - всегда возвращаем 42
                        registers[reg] = 42;
                    }
                }
                break;
            }
            case OUT: {
                if (operands.size() >= 2) {
                    uint8_t port = parseValue(operands[0]);
                    int reg = getRegisterIndex(operands[1]);
                    if (reg != -1) {
                        std::cout << "OUT port " << (int)port << ": " << (int)registers[reg] << std::endl;
                    }
                }
                break;
            }
            case HALT: {
                running = false;
                break;
            }
            case INC: {
                if (operands.size() >= 1) {
                    int reg = getRegisterIndex(operands[0]);
                    if (reg != -1) {
                        registers[reg]++;
                        updateFlags(registers[reg]);
                    }
                }
                break;
            }
            case DEC: {
                if (operands.size() >= 1) {
                    int reg = getRegisterIndex(operands[0]);
                    if (reg != -1) {
                        registers[reg]--;
                        updateFlags(registers[reg]);
                    }
                }
                break;
            }
            case TEST: {
                if (operands.size() >= 2) {
                    uint8_t val1 = isRegister(operands[0]) ? registers[getRegisterIndex(operands[0])] : parseValue(operands[0]);
                    uint8_t val2 = isRegister(operands[1]) ? registers[getRegisterIndex(operands[1])] : parseValue(operands[1]);
                    flags[0] = ((val1 & val2) == 0);
                }
                break;
            }
            case JZ: {
                if (operands.size() >= 1 && flags[0]) {
                    if (labels.find(operands[0]) != labels.end()) {
                        pc = labels[operands[0]] - 1;
                    }
                }
                break;
            }
            case JG: {
                if (operands.size() >= 1 && flags[2]) {
                    if (labels.find(operands[0]) != labels.end()) {
                        pc = labels[operands[0]] - 1;
                    }
                }
                break;
            }
            case JGE: {
                if (operands.size() >= 1 && (flags[0] || flags[2])) {
                    if (labels.find(operands[0]) != labels.end()) {
                        pc = labels[operands[0]] - 1;
                    }
                }
                break;
            }
            case JL: {
                if (operands.size() >= 1 && flags[1]) {
                    if (labels.find(operands[0]) != labels.end()) {
                        pc = labels[operands[0]] - 1;
                    }
                }
                break;
            }
            case JLE: {
                if (operands.size() >= 1 && (flags[0] || flags[1])) {
                    if (labels.find(operands[0]) != labels.end()) {
                        pc = labels[operands[0]] - 1;
                    }
                }
                break;
            }
            case JNZ: {
                if (operands.size() >= 1 && !flags[0]) {
                    if (labels.find(operands[0]) != labels.end()) {
                        pc = labels[operands[0]] - 1;
                    }
                }
                break;
            }
        }
    }
    
    void executeMachineCode(uint8_t code, std::istringstream& iss) {
        auto it = machineCodeMap.find(code);
        if (it == machineCodeMap.end()) {
            std::cout << "Unknown machine code: 0x" << std::hex << (int)code << std::endl;
            return;
        }
        
        // Собираем все операнды в строку
        std::string operandsStr;
        std::string operand;
        while (iss >> operand) {
            if (operand != ",") {
                operandsStr += operand + " ";
            }
        }
        
        // Создаем новый istringstream для мнемонической инструкции
        std::istringstream new_iss(operandsStr);
        
        // Выполняем соответствующую мнемоническую инструкцию
        switch (it->second) {
            case ADD: executeMnemonic("ADD", new_iss); break;
            case SUB: executeMnemonic("SUB", new_iss); break;
            case JG: executeMnemonic("JG", new_iss); break;
            case RET: executeMnemonic("RET", new_iss); break;
            case MUL: executeMnemonic("MUL", new_iss); break;
            case DIV: executeMnemonic("DIV", new_iss); break;
            case AND: executeMnemonic("AND", new_iss); break;
            case OR: executeMnemonic("OR", new_iss); break;
            case XOR: executeMnemonic("XOR", new_iss); break;
            case NOT: executeMnemonic("NOT", new_iss); break;
            case SHL: executeMnemonic("SHL", new_iss); break;
            case SHR: executeMnemonic("SHR", new_iss); break;
            case ROTATE: executeMnemonic("ROTATE", new_iss); break;
            case INC: executeMnemonic("INC", new_iss); break;
            case DEC: executeMnemonic("DEC", new_iss); break;
            case PUSH: executeMnemonic("PUSH", new_iss); break;
            case POP: executeMnemonic("POP", new_iss); break;
            case CALL: executeMnemonic("CALL", new_iss); break;
            case TEST: executeMnemonic("TEST", new_iss); break;
            case JZ: executeMnemonic("JZ", new_iss); break;
            case JNZ: executeMnemonic("JNZ", new_iss); break;
            case JL: executeMnemonic("JL", new_iss); break;
            case JGE: executeMnemonic("JGE", new_iss); break;
            case JLE: executeMnemonic("JLE", new_iss); break;
            case HALT: executeMnemonic("HALT", new_iss); break;
            case LOAD: executeMnemonic("LOAD", new_iss); break;
            case STORE: executeMnemonic("STORE", new_iss); break;
            case IN: executeMnemonic("IN", new_iss); break;
            case OUT: executeMnemonic("OUT", new_iss); break;
            case NOP: executeMnemonic("NOP", new_iss); break;
            case MOV: executeMnemonic("MOV", new_iss); break;
            case CMP: executeMnemonic("CMP", new_iss); break;
            case JE: executeMnemonic("JE", new_iss); break;
            case JNE: executeMnemonic("JNE", new_iss); break;
            case JMP: executeMnemonic("JMP", new_iss); break;
        }
    }
    
    void printState() {
        std::cout << "\n=== Program State ===" << std::endl;
        std::cout << "PC: 0x" << std::hex << pc << " SP: 0x" << sp << std::endl;
        
        std::cout << "Registers: ";
        for (int i = 0; i < 8; i++) {
            std::cout << "R" << i << "=0x" << std::hex << std::setw(2) << std::setfill('0') 
                     << (int)registers[i] << " ";
        }
        std::cout << "\nFlags: Z=" << flags[0] << " C=" << flags[1] << " S=" << flags[2] << std::endl;
        
        // Показываем первые 16 байт памяти
        std::cout << "Memory [0x0000-0x000F]: ";
        for (int i = 0; i < 16; i++) {
            std::cout << "0x" << std::hex << std::setw(2) << std::setfill('0') 
                     << (int)memory[i] << " ";
        }
        std::cout << std::dec << std::endl;
    }
};

int main() {
    // Пример программы - вычисление факториала 5
    std::vector<std::string> program = {
        "; Вычисление факториала 5",
        "START: MOV R1, 5     ; Загружаем число 5",
        "MOV R2, 1           ; Инициализируем результат",
        "",
        "FACTORIAL_LOOP: CMP R1, 1",
        "JE END              ; Если R1 == 1, заканчиваем",
        "MUL R2, R1          ; R2 = R2 * R1",
        "0x5B R1            ; DEC R1 (машинный код 0x5B)",
        "JMP FACTORIAL_LOOP  ; Повторяем цикл",
        "",
        "END: STORE [0x0100], R2 ; Сохраняем результат",
        "OUT 1, R2          ; Вывод результата",
        "HALT               ; Завершение программы"
    };
    
    HybridAsmInterpreter interpreter(program);
    std::cout << "Starting HybridAsm Interpreter..." << std::endl;
    std::cout << "Calculating factorial of 5..." << std::endl;
    interpreter.execute();
    interpreter.printState();
    
    return 0;
}
